package com.tom.demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TomController implements  ITomController {
    @Override
    public ResponseEntity<String> show() {
        return ResponseEntity.ok("show success");
    }
}
